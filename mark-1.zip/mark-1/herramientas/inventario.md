# Inventario de herramientas

Anota aquí cada aplicación o plataforma que uso.

| Herramienta | Para qué sirve | Pendiente en ella | ¿La sigo usando? |
|---|---|---|---|
| (ejemplo) Calendario | Ver mis horarios | Agendar la semana | Sí |
|  |  |  |  |

## Cómo mantenerlo
- Cada vez que empiece a usar una app nueva, la agrego a la tabla.
- Cada mes reviso cuáles no usé y decido si dejarlas.
