# mark 1

Mi asistente personal de estudios, organización y desarrollo digital.

## Qué es
Un espacio para organizar mis estudios y aprender a crear sitios web, apps y publicidad para negocios y emprendimientos. Empiezo desde cero.

## Carpetas
- `horario/`: mi horario fijo y mi agenda semanal.
- `herramientas/`: inventario de las aplicaciones y plataformas que uso.
- `aprendizaje/`: ruta de aprendizaje digital y ejercicios.
- `clientes/`: portafolio, propuestas y plan para conseguir clientes.
- `diario/`: registro diario de lo que avancé y lo que toca mañana.

## Cómo lo uso
1. Cada tarde (3:30 pm): le digo a Claude "hoy tengo poca tarea" o "hoy tengo mucha" y me da el plan.
2. Cada domingo: planifico la semana.
3. Cada día cierro con 10 minutos en `diario/`.
