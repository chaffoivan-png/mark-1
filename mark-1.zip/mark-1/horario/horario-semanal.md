# Horario fijo (lunes a viernes)

| Hora | Actividad |
|---|---|
| 7:30 am - 2:00 pm | Estudio |
| 2:10 pm - 3:30 pm | Almuerzo y descanso |
| 3:30 pm - 7:50 pm | Tareas y otros deberes |
| Después de 7:50 pm | Tiempo libre |

## Reglas de la tarde (3:30 - 7:50 pm)
1. Primero lo obligatorio, ordenado por urgencia.
2. Luego, bloque de práctica digital (si termino temprano, empiezo apenas acabe).
3. Día pesado: mínimo 45 minutos de práctica digital antes de las 7:50 pm.
4. Cierre: 10 minutos para anotar lo que avancé y lo que toca mañana.

## Fines de semana
- Sábado: recuperar lo que no avancé entre semana.
- Domingo: descanso y planificación.

## Agenda de esta semana
(pendiente: pedirle a Claude "arma mi semana")
