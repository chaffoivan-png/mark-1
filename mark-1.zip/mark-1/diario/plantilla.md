# Diario - AAAA-MM-DD

**Día:** poca tarea / mucha tarea

## Lo que avancé
- 

## Práctica digital (minutos)


## Lo que toca mañana
- 
