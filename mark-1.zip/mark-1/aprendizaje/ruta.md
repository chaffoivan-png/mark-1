# Ruta de aprendizaje digital

Orden sugerido (marca lo que vaya completando):

- [ ] 1. Cómo funciona una página web (qué es HTML, CSS, hosting y dominio)
- [ ] 2. HTML básico: títulos, párrafos, imágenes, enlaces
- [ ] 3. CSS básico: colores, tipografía, espacios
- [ ] 4. Mi primera página: tarjeta de presentación personal
- [ ] 5. Herramientas sin código para crear sitios para negocios
- [ ] 6. Marketing digital: qué necesita un emprendimiento para venderse
- [ ] 7. Mi primer anuncio de práctica para un negocio imaginario
- [ ] 8. Introducción a crear apps

## Ejercicios pequeños
(Claude te los va dando; anótalos aquí con la fecha.)
