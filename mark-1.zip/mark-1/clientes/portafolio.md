# Portafolio y primeros clientes

## Mis servicios (borrador)
- Páginas web simples para negocios
- Textos y diseños de publicidad
- (más adelante) Apps

## Proyectos de práctica
| Proyecto | Para quién | Estado | Enlace |
|---|---|---|---|
|  |  |  |  |

## Plan para primeros clientes
- [ ] Hacer 2 proyectos de práctica para mostrar
- [ ] Armar mi portafolio con esos proyectos
- [ ] Hacer una lista de 10 negocios cercanos
- [ ] Escribir un mensaje de presentación
- [ ] Contactar a los primeros 3
